# soulhealerProject
Android App which has functionalities like chatbot, todo list, meditation &amp; news articles related to mental health

